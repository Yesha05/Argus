// --- AUTHENTICATION CHECK ---
document.addEventListener('DOMContentLoaded', () => {
    // Check if user is logged in
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        window.location.href = 'login.html';
        return; // Stop execution if not logged in
    }

    // Parse user data
    const userData = JSON.parse(currentUser);
    
    // Update UI with user data
    const updateUserInterface = () => {
        // Update profile popup username
        const profileUserName = document.querySelector('.profile-user-name');
        if (profileUserName) {
            profileUserName.textContent = userData.username;
        }
        
        // Update settings panel username
        const accountInfoElements = document.querySelectorAll('#my-account-panel p');
        accountInfoElements.forEach(element => {
            if (element.textContent.includes('Username:')) {
                element.textContent = `Username: ${userData.username}`;
            }
            if (element.textContent.includes('Email:')) {
                element.textContent = `Email: ${userData.email}`;
            }
        });
        
        // Update change username panel placeholder
        const usernameInput = document.querySelector('#change-username-panel input[type="text"]');
        if (usernameInput) {
            usernameInput.value = userData.username;
        }
    };

    // Call this function to update UI
    updateUserInterface();

    // --- REST OF YOUR EXISTING CODE CONTINUES HERE ---
    // UI Elements
    const mainContainer = document.querySelector(".main-container");
    const chatbox = document.querySelector(".chatbox");
    const chatInput = document.querySelector(".chat-input textarea");
    const sendBtn = document.getElementById("send-btn");
    const micBtn = document.querySelector(".mic-btn");
    
    // History/Archive Elements
    const historyList = document.querySelector(".history-list");
    const newChatBtn = document.querySelector(".new-chat-btn");
    const archiveChatsBtn = document.querySelector(".archive-chats-btn"); 
    const sidebarHistory = document.querySelector(".sidebar-history");
    const sidebarArchiveList = document.querySelector(".sidebar-archive-list"); 
    const archiveList = document.querySelector(".archive-list"); 
    const chatHistoryInSettings = document.getElementById('chat-history-in-settings'); // New

    // Context Menu Elements
    const contextMenu = document.getElementById('chat-context-menu'); 
    const archiveAction = contextMenu.querySelector('.archive-action'); 
    const deleteAction = contextMenu.querySelector('.delete-action'); 
    let contextMenuTargetChatId = null; 

    const voiceStatusText = document.querySelector(".voice-status");

    // Videos
    const voiceVideoBg = document.getElementById('voice-video-bg');
    const voiceVideoSmall = document.getElementById('voice-video-bg-small');

    // Profile Pop-up
    const profileIcon = document.querySelector('.profile-icon');
    const profilePopup = document.getElementById('profile-popup');
    const closeProfileBtn = profilePopup.querySelector('.profile-popup-close-btn');
    const popupLogoutBtn = profilePopup.querySelector('.log-out-btn-popup'); // Log Out on the pop-up
    const popupNavAvatar = document.getElementById('nav-avatar'); // Small avatar in nav bar
    const popupNavIcon = document.getElementById('nav-icon'); // Icon in nav bar
    const popupAvatar = document.getElementById('popup-avatar'); // Large avatar in popup
    const popupIcon = document.getElementById('popup-icon'); // Icon in popup

    // Settings Board Elements
    const settingsBoard = document.getElementById('settings-board');
    const triggerSettingsBtns = document.querySelectorAll('.trigger-settings-btn'); // Multiple buttons in pop-up now
    const closeSettingsBtns = document.querySelectorAll('.close-settings-btn');
    const settingsNavItems = document.querySelectorAll('.settings-nav-item');
    const settingsPanels = document.querySelectorAll('.settings-panel');
    const settingsAvatar = document.getElementById('settings-avatar'); // Large avatar in settings panel
    const settingsIcon = document.getElementById('settings-icon'); // Icon in settings panel
    
    // My Account Panel Buttons
    const accountActionBtns = document.querySelectorAll('.account-action-btn'); 
    const backToAccountBtns = document.querySelectorAll('.back-to-account'); 
    const addPhoneBtn = document.getElementById('add-phone-btn'); // New
    const removePhoneBtn = document.getElementById('remove-phone-btn'); // New
    const phoneNumberInput = document.getElementById('phone-number-input'); // New
    
    // Global Log Out and Delete Buttons
    const navLogoutBtn = document.querySelector('.settings-nav-item.log-out-btn'); 
    const deleteAccountNavBtn = document.querySelector('.delete-account-btn'); 
    const deleteAccountConfirmBtn = document.querySelector('.delete-account-confirm-btn');
    
    // Profile Upload Elements
    const avatarUploadInput = document.getElementById('avatar-upload'); // File input
    const removeAvatarBtn = document.getElementById('remove-avatar-btn'); // Remove button

    // --- CHAT AND HISTORY STATE MANAGEMENT ---
    let chatHistory = [
         { id: 'initial-1', title: 'First ever chat!', messages: [{role: 'outgoing', text: 'Hello VidyAI!'}, {role: 'incoming', text: 'Hi there 👋'}], isArchived: false, date: Date.now() - 86400000 * 2 },
         { id: 'initial-2', title: 'Another long session...', messages: [{role: 'outgoing', text: 'Test chat for history display.'}], isArchived: false, date: Date.now() - 86400000 },
    ]; 
    let currentChatId = null;
    let isArchiveView = false; 

    const generateUniqueId = () => Date.now().toString(36) + Math.random().toString(36).substr(2);
    const getCurrentChat = () => chatHistory.find(chat => chat.id === currentChatId);

    const createChatLi = (message, role) => {
        const chatLi = document.createElement("li");
        chatLi.classList.add("chat", role);
        
        if (role === "incoming") {
            chatLi.innerHTML = `
                <p>${message}</p>
                <div class="chat-actions">
                    <button class="chat-action-btn voice-btn" title="Listen to this message">
                        <i class="fas fa-volume-up"></i>
                    </button>
                    <button class="chat-action-btn copy-btn" title="Copy message">
                        <i class="fas fa-copy"></i>
                    </button>
                    <button class="chat-action-btn like-btn" title="Like this response">
                        <i class="far fa-thumbs-up"></i>
                    </button>
                    <button class="chat-action-btn dislike-btn" title="Dislike this response">
                        <i class="far fa-thumbs-down"></i>
                    </button>
                    <span class="confidence-score">95%</span>
                </div>
            `;
        } else {
            chatLi.innerHTML = `<p>${message}</p>`;
        }
        return chatLi;
    };

    const toggleArchiveView = (showArchive) => {
        isArchiveView = showArchive;
        if (isArchiveView) {
            sidebarHistory.style.display = 'none';
            sidebarArchiveList.style.display = 'block';
            archiveChatsBtn.innerHTML = '<i class="fas fa-history"></i> Recent Chats';
            archiveChatsBtn.classList.add('active-archive-view');
        } else {
            sidebarHistory.style.display = 'block';
            sidebarArchiveList.style.display = 'none';
            archiveChatsBtn.innerHTML = '<i class="fas fa-archive"></i> Archived Chats';
            archiveChatsBtn.classList.remove('active-archive-view');
        }
        renderHistoryList();
    };

    const loadChat = (chatId) => {
        if (currentChatId) {
             saveCurrentChat(); 
        }

        const chatToLoad = chatHistory.find(chat => chat.id === chatId);
        if (!chatToLoad) return;

        if (chatToLoad.isArchived && isArchiveView) {
            toggleArchiveView(false);
        }

        currentChatId = chatId;
        
        chatbox.innerHTML = '';
        if (chatToLoad.messages.length === 0) {
             const welcomeMsg = createChatLi("Hi there 👋<br>How can I help you today?", "incoming");
             chatbox.appendChild(welcomeMsg);
        } else {
             chatToLoad.messages.forEach(msg => {
                const chatLi = createChatLi(msg.text, msg.role);
                chatbox.appendChild(chatLi);
            });
        }
       
        chatbox.scrollTo(0, chatbox.scrollHeight);
        renderHistoryList();
    };


    const startNewChat = () => {
        if (currentChatId) {
            saveCurrentChat(); 
        }
        
        if (isArchiveView) {
             toggleArchiveView(false);
        }

        const newChat = {
            id: generateUniqueId(),
            title: "New Chat",
            messages: [],
            isArchived: false,
            date: Date.now() 
        };
        chatHistory.unshift(newChat); 
        loadChat(newChat.id); 
        chatInput.value = "";
    };


    const saveCurrentChat = () => {
        const currentChat = getCurrentChat();
        if (!currentChat) return;

        const firstUserMessage = currentChat.messages.find(msg => msg.role === 'outgoing');
        if (firstUserMessage) {
            currentChat.title = firstUserMessage.text.substring(0, 30) + (firstUserMessage.text.length > 30 ? '...' : '');
        } else if (currentChat.messages.length > 0) {
            currentChat.title = "Chat Session";
        } else {
             if (currentChat.id === currentChatId && !currentChat.isArchived) {
                 chatHistory = chatHistory.filter(chat => chat.id !== currentChatId);
                 currentChatId = null;
             }
        }
    };
    
    const toggleArchiveChat = (chatId) => {
        const chat = chatHistory.find(c => c.id === chatId);
        if (chat) {
            chat.isArchived = isArchiveView ? false : true;
            renderHistoryList();
        }
    };
    
    const deleteChat = (chatId) => {
        if (chatId === currentChatId) {
            startNewChat();
        }
        chatHistory = chatHistory.filter(c => c.id !== chatId);
        renderHistoryList();
    };

    const formatDate = (timestamp) => {
        const date = new Date(timestamp);
        return date.toLocaleDateString('en-IN', {
             day: 'numeric', month: 'short', year: 'numeric'
        });
    }

    const renderHistoryList = () => {
        historyList.innerHTML = '';
        archiveList.innerHTML = '';
        chatHistoryInSettings.innerHTML = ''; // Clear settings list

        // Sort by date descending (most recent first)
        const sortedHistory = chatHistory.sort((a, b) => b.date - a.date);

        const recentChats = sortedHistory.filter(chat => !chat.isArchived && chat.messages.length > 0);
        const archivedChats = sortedHistory.filter(chat => chat.isArchived);
        
        // Render Recent Chats (Sidebar)
        recentChats.forEach(chat => {
            const li = createHistoryListItem(chat, false);
            historyList.appendChild(li);
        });

        // Render Archived Chats (Sidebar)
        archivedChats.forEach(chat => {
            const li = createHistoryListItem(chat, true);
            archiveList.appendChild(li);
        });
        
        // Render Chat History in Settings Panel (NEW)
        recentChats.forEach(chat => {
            const li = document.createElement('li');
            li.innerHTML = `<span class="chat-title">${chat.title}</span><span class="chat-date">${formatDate(chat.date)}</span>`;
            chatHistoryInSettings.appendChild(li);
        });
        
        if (recentChats.length === 0 && !isArchiveView && currentChatId === null) {
             startNewChat();
        }
    };

    const createHistoryListItem = (chat, inArchive) => {
        const li = document.createElement('li');
        li.textContent = chat.title;
        li.dataset.chatId = chat.id;
        if (chat.id === currentChatId) {
            li.classList.add('active-chat');
        }
        li.addEventListener('click', () => loadChat(chat.id));
        li.addEventListener('contextmenu', (e) => showContextMenu(e, chat.id, inArchive)); 
        return li;
    };
    
    startNewChat(); 
    // --- END CHAT MANAGER ---


    // --- CONTEXT MENU (DROPDOWN) LOGIC ---
    const showContextMenu = (e, chatId, inArchive) => {
        e.preventDefault(); 
        contextMenuTargetChatId = chatId;

        contextMenu.style.top = `${e.clientY}px`;
        contextMenu.style.left = `${e.clientX}px`;
        
        if (inArchive) {
            archiveAction.innerHTML = '<i class="fas fa-undo-alt"></i> Unarchive';
        } else {
            archiveAction.innerHTML = '<i class="fas fa-archive"></i> Archive';
        }

        contextMenu.style.display = 'block';
    };

    document.addEventListener('click', (e) => {
        if (!contextMenu.contains(e.target)) {
            contextMenu.style.display = 'none';
            contextMenuTargetChatId = null;
        }
        if (e.target === profilePopup) {
            profilePopup.classList.remove('show-popup');
        }
    });

    archiveAction.addEventListener('click', () => {
        if (contextMenuTargetChatId) {
            toggleArchiveChat(contextMenuTargetChatId);
            contextMenu.style.display = 'none';
        }
    });

    deleteAction.addEventListener('click', () => {
        if (contextMenuTargetChatId) {
            if (window.confirm("Are you sure you want to permanently delete this chat?")) {
                deleteChat(contextMenuTargetChatId);
            }
            contextMenu.style.display = 'none';
        }
    });
    // --- END CONTEXT MENU LOGIC ---
    
    
    // --- SETTINGS BOARD LOGIC (Updated for Sub-panels and new footer items) ---
    
    const showSettingsBoard = (panelId) => {
        profilePopup.classList.remove('show-popup');
        settingsBoard.classList.add('show');
        if (panelId) {
            switchSettingsPanel(panelId);
        }
    };
    
    const hideSettingsBoard = () => {
        settingsBoard.classList.remove('show');
    };
    
    // Core function to show the correct panel and highlight the correct main nav item
    const switchSettingsPanel = (panelId) => {
        // Hide all panels
        settingsPanels.forEach(panel => panel.classList.remove('active'));
        
        // Determine the main navigation category. Sub-panels use their parent's category.
        let mainPanelId;
        if (panelId === 'change-username' || panelId === 'change-password') {
             mainPanelId = 'my-account';
        } else {
             mainPanelId = panelId;
        }
        
        // Reset and highlight the main navigation item for the *category*
        settingsNavItems.forEach(item => item.classList.remove('active'));
        const activeNav = document.querySelector(`.settings-nav-item[data-panel="${mainPanelId}"]`);
        if (activeNav) activeNav.classList.add('active');

        // Show the specific panel.
        const activePanel = document.getElementById(`${panelId}-panel`);
        if (activePanel) activePanel.classList.add('active');
        
        // Special case: if chat history panel is opened, re-render the list
        if (panelId === 'chat-history') {
             renderHistoryList();
        }
    };

    // --- MOCK ACTIONS FOR PHONE NUMBER, LOG OUT, DELETE ACCOUNT ---
    
    const mockAddPhone = () => {
        const phone = phoneNumberInput.value.trim();
        if (phone.length !== 10 || isNaN(phone)) {
             alert("Error: Phone number must be exactly 10 digits.");
             return;
        }
        // In a real app, this would send an API request to add the number
        alert(`Phone number (${phone}) added successfully! (Mock Action)`);
        // Optional: clear input and/or show confirmation badge
        phoneNumberInput.value = '';
    };

    const mockRemovePhone = () => {
        // In a real app, this would send an API request to remove the number
        alert("Phone number removed successfully! (Mock Action)");
        phoneNumberInput.value = ''; // Clear as if removed
    };
    
    const mockLogout = () => {
        // Clear user session
        localStorage.removeItem('currentUser');
        // Redirect to login page
        window.location.href = 'login.html';
    };

    const mockDeleteAccount = () => {
         window.alert("Account deletion confirmed! (Mock action - Permanent)");
         hideSettingsBoard();
         // In a real app, this would send an API request to delete the user and redirect to the login screen
    };
    
    // --- EVENT LISTENERS FOR SETTINGS BOARD ---
    
    closeSettingsBtns.forEach(btn => btn.addEventListener('click', hideSettingsBoard));
    
    // Listener for main navigation items (including new Log Out/Delete Account)
    settingsNavItems.forEach(item => {
        item.addEventListener('click', function() {
            const panelId = this.dataset.panel;
            switchSettingsPanel(panelId);
        });
    });
    
    // Listener for Profile Pop-up menu items (NEW)
    triggerSettingsBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const panelId = this.dataset.panel;
            showSettingsBoard(panelId); // Open board directly to the target panel
        });
    });


    // Listener for "Change Username" and "Change Password" buttons inside My Account
    accountActionBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const targetPanelId = this.dataset.target; 
            switchSettingsPanel(targetPanelId);
        });
    });

    // Listener for "Back to My Account" buttons in sub-panels
    backToAccountBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            switchSettingsPanel('my-account');
        });
    });
    
    // Phone Number button listeners (NEW)
    addPhoneBtn.addEventListener('click', mockAddPhone);
    removePhoneBtn.addEventListener('click', mockRemovePhone);

    // Log Out handlers (multiple locations trigger the same mock action)
    popupLogoutBtn.addEventListener('click', mockLogout);
    
    // We add a listener for the Log Out button in the main nav which brings up the 'logout-panel'
    // and the actual action is tied to the button inside that panel for a confirmation step.
    const confirmLogoutButton = document.querySelector('#logout-panel .log-out-btn');
    if (confirmLogoutButton) {
        confirmLogoutButton.addEventListener('click', mockLogout);
    }

    // Delete Account confirmation button
    deleteAccountConfirmBtn.addEventListener('click', mockDeleteAccount);
    
    // Default to the first panel on load (My Account)
    switchSettingsPanel('my-account');
    
    // --- END SETTINGS BOARD LOGIC ---
    
    
    // --- PROFILE PICTURE LOGIC (NEW) ---
    const updateProfileAvatar = (imageUrl) => {
        if (imageUrl) {
            // Update all avatar elements to the new image
            popupNavAvatar.src = imageUrl;
            popupAvatar.src = imageUrl;
            settingsAvatar.src = imageUrl;
            
            // Show images, hide icons
            popupNavAvatar.style.display = 'block';
            popupNavIcon.style.display = 'none';
            popupAvatar.style.display = 'block';
            popupIcon.style.display = 'none';
            settingsAvatar.style.display = 'block';
            settingsIcon.style.display = 'none';
        } else {
             // Reset to default icon
            popupNavAvatar.src = '';
            popupAvatar.src = '';
            settingsAvatar.src = '';
            
            // Show icons, hide images
            popupNavAvatar.style.display = 'none';
            popupNavIcon.style.display = 'block';
            popupAvatar.style.display = 'none';
            popupIcon.style.display = 'block';
            settingsAvatar.style.display = 'none';
            settingsIcon.style.display = 'block';
        }
    };
    
    // Listener for file selection (This is the fix for "not updating the photo")
    avatarUploadInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                updateProfileAvatar(e.target.result);
                alert("Photo selected! (Mock Upload Success). The new avatar is now visible.");
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Listener for the "Remove" button
    removeAvatarBtn.addEventListener('click', () => {
        updateProfileAvatar(null);
        // Also clear the file input so selecting the same file again works
        avatarUploadInput.value = ''; 
        alert("Photo removed successfully! (Mock Action)");
    });
    
    // Initialize avatar to default icon state
    updateProfileAvatar(null); 
    // --- END PROFILE PICTURE LOGIC ---

    
    // --- UI HELPER FUNCTIONS & VOICE RECOGNITION (Kept) ---
    
    // Text-to-Speech function
    const speakText = (text) => {
        // Remove HTML tags for clean speech
        const cleanText = text.replace(/<br>/g, '. ').replace(/<[^>]*>/g, '');
        
        if ('speechSynthesis' in window) {
            // Stop any ongoing speech
            speechSynthesis.cancel();
            
            const speech = new SpeechSynthesisUtterance(cleanText);
            speech.rate = 0.9;
            speech.pitch = 1;
            speech.volume = 1;
            
            // Get available voices and try to use a female voice if available
            const voices = speechSynthesis.getVoices();
            const femaleVoice = voices.find(voice => 
                voice.name.includes('Female') || 
                voice.name.includes('woman') || 
                voice.name.includes('Google UK English Female') ||
                voice.name.includes('Microsoft Zira')
            );
            
            if (femaleVoice) {
                speech.voice = femaleVoice;
            }
            
            speechSynthesis.speak(speech);
            
            return speech;
        } else {
            alert("Text-to-speech is not supported in your browser.");
            return null;
        }
    };

    // Calculate confidence score based on message type
    const calculateConfidenceScore = (message) => {
        // For predefined responses, give high confidence
        if (message.includes("Hello! How can I help you today?") || 
            message.includes("PM-Vidyalaxmi") || 
            message.includes("Hi, I am here to help you")) {
            return "95%";
        }
        // For other responses, random high score
        const scores = ["92%", "94%", "96%", "98%"];
        return scores[Math.floor(Math.random() * scores.length)];
    };

    const generateResponse = async (chatElement, userText) => {
        const messageElement = chatElement.querySelector("p");
        messageElement.textContent = "Thinking..."; 

        try {
            // Custom response logic based on user input
            let botMessage = "";
            let confidenceScore = "95%";
            let showSource = false;
            
            // Convert user input to lowercase for case-insensitive matching
            const userInput = userText.toLowerCase().trim();
            
            // Custom responses for specific prompts
            if (userInput.includes("hi vidyai") || userInput === "hi" || userInput === "hello") {
                botMessage = "Hello! How can I help you today?";
                confidenceScore = "98%";
                showSource = false;
            } else if (userInput.includes("tell me about the pm vidyalaxmi scheme") || 
                       userInput.includes("pm vidyalaxmi scheme") || 
                       userInput.includes("vidyalaxmi scheme")) {
                botMessage = `The Pradhan Mantri Vidyalaxmi (PM-Vidyalaxmi) Scheme is a Central Sector Scheme approved on November 6, 2024, to provide financial support for higher education, ensuring that financial constraints do not prevent meritorious students from pursuing quality higher education in domestic institutions.<br><br>Key features include:<br>1. A collateral-free, guarantor-free education loan product for meritorious students admitted to top 860 Quality Higher Educational Institutions (QHEIs) through open competitive examinations/merit-based admission.<br>2. The loan amount has no cut-off ceiling and depends on course fees and associated expenses.<br>3. Loans up to ₹7.5 lakhs are eligible for a 75% credit guarantee by the Government of India.<br>4. Students with an annual family income of up to ₹8 lakhs are eligible for a 3% interest subvention on loans up to ₹10 lakhs during the moratorium period (Course period + 1 year). This is in addition to the full interest subvention already offered to students with up to ₹4.5 lakhs annual family income under the PM-USP CSIS scheme for technical/professional courses.<br>5. The application process is simple, transparent, student-friendly, and entirely digital.<br>6. The scheme applies to education loans sanctioned after November 6, 2024.`;
                confidenceScore = "96%";
                showSource = true;
            } else {
                // Default response for other queries
                botMessage = "Hi, I am here to help you. What can I do next?";
                confidenceScore = "94%";
                showSource = false;
            }

            // Use innerHTML to render the HTML line breaks properly
            messageElement.innerHTML = botMessage;

            // Update confidence score
            const confidenceElement = chatElement.querySelector('.confidence-score');
            if (confidenceElement) {
                confidenceElement.textContent = confidenceScore;
            }

            // Add source indicator BELOW the response (moved from beside buttons)
            if (showSource) {
                const sourceIndicator = document.createElement('div');
                sourceIndicator.className = 'source-indicator';
                sourceIndicator.innerHTML = '<div class="source-box"><strong>Source:</strong> PM_Vidyalaxmi_Scheme_Guidelines.txt</div>';
                // Insert the source indicator after the chat actions
                chatElement.appendChild(sourceIndicator);
            }

            const currentChat = getCurrentChat();
            if (currentChat) {
                // Store the message with HTML for display but use text for history
                currentChat.messages.push({ role: 'incoming', text: botMessage });
                renderHistoryList();
            }

        } catch (error) {
            messageElement.classList.add("error");
            messageElement.textContent = "Oops! Something went wrong. Please try again.";
        }
        chatbox.scrollTo(0, chatbox.scrollHeight);
    };

    const handleChat = (inputMessage) => {
        const userText = inputMessage.trim();
        if (!userText) return;

        const currentChat = getCurrentChat();
        if (currentChat) {
            // Update chat date only on first message to preserve original date
            if (currentChat.messages.length === 0) {
                 currentChat.date = Date.now();
            }
            currentChat.messages.push({ role: 'outgoing', text: userText });
        }
        
        chatInput.value = "";
        const outgoingChatLi = createChatLi(userText, "outgoing");
        chatbox.appendChild(outgoingChatLi);
        chatbox.scrollTo(0, chatbox.scrollHeight);
        
        if (currentChat && currentChat.messages.length === 1) {
             saveCurrentChat();
             renderHistoryList();
        }

        setTimeout(() => {
            const incomingChatLi = createChatLi("Thinking...", "incoming");
            chatbox.appendChild(incomingChatLi);
            chatbox.scrollTo(0, chatbox.scrollHeight);
            generateResponse(incomingChatLi, userText);
        }, 300);
    };

    // --- CHAT ACTION HANDLERS ---
    const handleChatActions = (e) => {
        if (e.target.closest('.voice-btn')) {
            const chatLi = e.target.closest('.chat');
            const messageText = chatLi.querySelector('p').textContent;
            speakText(messageText);
            
            // Add visual feedback
            const voiceBtn = e.target.closest('.voice-btn');
            voiceBtn.classList.add('playing');
            setTimeout(() => voiceBtn.classList.remove('playing'), 1000);
        }
        
        else if (e.target.closest('.copy-btn')) {
            const chatLi = e.target.closest('.chat');
            const messageText = chatLi.querySelector('p').textContent;
            navigator.clipboard.writeText(messageText).then(() => {
                const copyBtn = e.target.closest('.copy-btn');
                const originalIcon = copyBtn.innerHTML;
                copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                setTimeout(() => {
                    copyBtn.innerHTML = originalIcon;
                }, 2000);
            });
        }
        
        else if (e.target.closest('.like-btn')) {
            const likeBtn = e.target.closest('.like-btn');
            likeBtn.classList.toggle('liked');
            if (likeBtn.classList.contains('liked')) {
                likeBtn.innerHTML = '<i class="fas fa-thumbs-up"></i>';
                // If dislike is active, remove it
                const dislikeBtn = likeBtn.parentElement.querySelector('.dislike-btn');
                if (dislikeBtn.classList.contains('disliked')) {
                    dislikeBtn.classList.remove('disliked');
                    dislikeBtn.innerHTML = '<i class="far fa-thumbs-down"></i>';
                }
            } else {
                likeBtn.innerHTML = '<i class="far fa-thumbs-up"></i>';
            }
        }
        
        else if (e.target.closest('.dislike-btn')) {
            const dislikeBtn = e.target.closest('.dislike-btn');
            dislikeBtn.classList.toggle('disliked');
            if (dislikeBtn.classList.contains('disliked')) {
                dislikeBtn.innerHTML = '<i class="fas fa-thumbs-down"></i>';
                // If like is active, remove it
                const likeBtn = dislikeBtn.parentElement.querySelector('.like-btn');
                if (likeBtn.classList.contains('liked')) {
                    likeBtn.classList.remove('liked');
                    likeBtn.innerHTML = '<i class="far fa-thumbs-up"></i>';
                }
            } else {
                dislikeBtn.innerHTML = '<i class="far fa-thumbs-down"></i>';
            }
        }
    };

    // Add event delegation for chat actions
    chatbox.addEventListener('click', handleChatActions);
    
    // --- EVENT LISTENERS ---

    sendBtn.addEventListener("click", () => {
        handleChat(chatInput.value);
    });

    chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleChat(chatInput.value);
        }
    });

    newChatBtn.addEventListener('click', startNewChat);
    
    archiveChatsBtn.addEventListener('click', () => {
        toggleArchiveView(!isArchiveView);
    });


    // Profile Pop-up functionality (Toggle Pop-up)
    profileIcon.addEventListener('click', (e) => {
        e.stopPropagation(); 
        profilePopup.classList.toggle('show-popup');
    });

    // Close Profile Pop-up button
    closeProfileBtn.addEventListener('click', () => {
         profilePopup.classList.remove('show-popup');
    });

    // --- VOICE RECOGNITION SETUP (Kept) ---
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    let recognition;
    let isRecording = false;
    const defaultPlaceholder = "Enter Prompt"; 

    if (SpeechRecognition) {
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true; 

        recognition.onstart = () => {
            isRecording = true;
            micBtn.classList.add('recording');
            mainContainer.classList.add('voice-active'); 
            chatInput.placeholder = "Listening...";
            voiceStatusText.textContent = "Listening... Say your prompt.";
            
            if (voiceVideoBg) voiceVideoBg.play(); 
            if (voiceVideoSmall) voiceVideoSmall.play(); 
        };

        recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';

            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript;
                } else {
                    interimTranscript += event.results[i][0].transcript;
                }
            }
            chatInput.value = finalTranscript || interimTranscript;

            if (finalTranscript) {
                voiceStatusText.textContent = "Transcription complete. Hit send to search.";
            } else {
                voiceStatusText.textContent = `Listening: ${interimTranscript}`;
            }
        };

        recognition.onend = () => {
            isRecording = false;
            micBtn.classList.remove('recording');
            mainContainer.classList.remove('voice-active');
            
            chatInput.placeholder = defaultPlaceholder; 
            
            if (voiceVideoBg) { voiceVideoBg.pause(); voiceVideoBg.currentTime = 0; }
            if (voiceVideoSmall) { voiceVideoSmall.pause(); voiceVideoSmall.currentTime = 0; }
        };

        recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            micBtn.classList.remove('recording');
            isRecording = false;
            mainContainer.classList.remove('voice-active');
            
            chatInput.placeholder = defaultPlaceholder;
            
            if (voiceVideoBg) { voiceVideoBg.pause(); voiceVideoBg.currentTime = 0; }
            if (voiceVideoSmall) { voiceVideoSmall.pause(); voiceVideoSmall.currentTime = 0; }
        };

        micBtn.addEventListener('click', () => {
            if (isRecording) {
                recognition.stop();
            } else {
                chatInput.value = "";
                recognition.start();
            }
        });

    } else {
        micBtn.style.display = 'none'; 
    }
});